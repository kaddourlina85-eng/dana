document.querySelectorAll('.nav-toggle').forEach(btn=>{
  btn.addEventListener('click',()=>{
    const menu = btn.parentElement.querySelector('ul');
    if(menu) menu.classList.toggle('open');
  });
});

const revealEls = document.querySelectorAll('.reveal');
if('IntersectionObserver' in window){
  const io = new IntersectionObserver(entries=>{
    entries.forEach(e=>{if(e.isIntersecting)e.target.classList.add('in')});
  },{threshold:.12});
  revealEls.forEach(el=>io.observe(el));
}else{
  revealEls.forEach(el=>el.classList.add('in'));
}

document.querySelectorAll('.flip-phone').forEach(phone=>{
  phone.addEventListener('click',()=>phone.classList.toggle('open'));
});

const lightbox=document.querySelector('.lightbox');
if(lightbox){
  const lightboxImg=lightbox.querySelector('img');
  document.querySelectorAll('.gallery img').forEach(img=>{
    img.addEventListener('click',()=>{
      lightboxImg.src=img.src;
      lightbox.classList.add('open');
    });
  });
  const closeBtn=lightbox.querySelector('.lightbox-close');
  if(closeBtn) closeBtn.addEventListener('click',()=>lightbox.classList.remove('open'));
  lightbox.addEventListener('click',e=>{if(e.target===lightbox)lightbox.classList.remove('open')});
}
