Upload your own files here using these exact names:

headshot.jpg
photo1.jpg
photo2.jpg
photo3.jpg
art1.jpg
art2.jpg
art3.jpg
art4.jpg
art5.jpg
art6.jpg
song.mp3   (optional)

GitHub filenames are case-sensitive. Use lowercase exactly as shown.
