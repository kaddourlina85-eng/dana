window.addEventListener('load',()=>{
  document.querySelector('.loader')?.classList.add('hide');
});

document.querySelectorAll('.nav-toggle').forEach(btn=>{
  btn.addEventListener('click',()=>{
    btn.parentElement.querySelector('ul')?.classList.toggle('open');
  });
});

const revealEls=document.querySelectorAll('.reveal');
if('IntersectionObserver' in window){
  const io=new IntersectionObserver(entries=>{
    entries.forEach(e=>{if(e.isIntersecting)e.target.classList.add('in')});
  },{threshold:.12});
  revealEls.forEach(el=>io.observe(el));
}else revealEls.forEach(el=>el.classList.add('in'));

document.querySelectorAll('.flip-phone').forEach(phone=>{
  phone.addEventListener('click',()=>phone.classList.toggle('open'));
});

const lightbox=document.querySelector('.lightbox');
if(lightbox){
  const img=lightbox.querySelector('img');
  document.querySelectorAll('.gallery img').forEach(item=>{
    item.addEventListener('click',()=>{
      img.src=item.src;
      lightbox.classList.add('open');
    });
  });
  lightbox.querySelector('.lightbox-close')?.addEventListener('click',()=>lightbox.classList.remove('open'));
  lightbox.addEventListener('click',e=>{if(e.target===lightbox)lightbox.classList.remove('open')});
}

document.querySelectorAll('.easter-egg').forEach(egg=>{
  egg.addEventListener('click',()=>{
    egg.parentElement.querySelector('.secret')?.classList.toggle('show');
  });
});

const countdown=document.querySelector('[data-countdown]');
if(countdown){
  const target=new Date(countdown.dataset.countdown+'T00:00:00');
  const update=()=>{
    const diff=target-new Date();
    if(diff<=0){
      countdown.innerHTML='<div class="card"><h3>Happy Birthday Dana! 🎂</h3><p>Today is your day.</p></div>';
      launchConfetti();
      return;
    }
    const days=Math.floor(diff/86400000);
    const hours=Math.floor((diff%86400000)/3600000);
    const mins=Math.floor((diff%3600000)/60000);
    const secs=Math.floor((diff%60000)/1000);
    countdown.innerHTML=`
      <div class="timebox"><strong>${days}</strong>days</div>
      <div class="timebox"><strong>${hours}</strong>hours</div>
      <div class="timebox"><strong>${mins}</strong>minutes</div>
      <div class="timebox"><strong>${secs}</strong>seconds</div>`;
  };
  update();setInterval(update,1000);
}

function launchConfetti(){
  const colors=['#ff6fb0','#ffd8ea','#c81f6f','#fff0b8'];
  for(let i=0;i<70;i++){
    const c=document.createElement('div');
    c.className='confetti';
    c.style.left=Math.random()*100+'vw';
    c.style.background=colors[Math.floor(Math.random()*colors.length)];
    c.style.animationDelay=Math.random()*1.5+'s';
    c.style.transform=`rotate(${Math.random()*360}deg)`;
    document.body.appendChild(c);
    setTimeout(()=>c.remove(),5000);
  }
}

const music=document.getElementById('music');
const musicBtn=document.getElementById('musicBtn');
if(music&&musicBtn){
  musicBtn.addEventListener('click',async()=>{
    if(music.paused){
      try{await music.play();musicBtn.textContent='Pause music ⏸️';}
      catch{musicBtn.textContent='Add images/song.mp3 first';}
    }else{music.pause();musicBtn.textContent='Play her song ▶️';}
  });
}
